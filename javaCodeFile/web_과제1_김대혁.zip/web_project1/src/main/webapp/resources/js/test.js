/**
 * 
 */
$(function(){
	$("#login_btn").click(function(){
	var userId = document.getElementById("id").value;
	var pwd = document.getElementById("pw").value;
	
	alert(userId+":"+pwd);
	});
	});
