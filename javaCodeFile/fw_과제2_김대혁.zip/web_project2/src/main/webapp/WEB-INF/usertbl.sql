
drop table USERTBL;

create table userTBL(
	id varchar(8) primary key,
	password varchar(8),
	userName varchar(20)
	)

insert into USERTBL values('a','1234','kim');

insert into USERTBL values('user','2354','lee');

insert into USERTBL values('tester','5214','park');
SELECT * from USERTBL;