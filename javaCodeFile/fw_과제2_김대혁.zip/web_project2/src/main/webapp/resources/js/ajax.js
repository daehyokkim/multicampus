/**
 * 
 */

$(function(){
	$("#login_btn").click(function(){
	var id = document.getElementById("id").value;
	var password = document.getElementById("password").value;
	var _jsoninfo = '{"id":"'+id+'","password":"'+password+'"}';

	$.ajax({
		type : "post",
		cache : false,
		url : "member/login.do",
		data : {jsonInfo : _jsoninfo},
		success:function (data,textStatus){
		var jsonInfo = JSON.parse(data);
		if(jsonInfo != null){
		alert("Data: "+jsonInfo.id + " login ok \n"+"status: success" );
		}
		else{
		alert("check id or pwd ");
		}
     },
     error:function(datWa,textStatus){
        alert("error");
     }
	});
	
	});
	});
