package mc.sn.project.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import mc.sn.project.vo.MemberVO;

public interface MemberDAO {
	 public MemberVO loginById(MemberVO memberVO) throws DataAccessException;

}
