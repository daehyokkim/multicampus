package mc.sn.project.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import mc.sn.project.vo.MemberVO;


public interface MemberService {
	 public MemberVO login(MemberVO memberVO) throws Exception;
}
