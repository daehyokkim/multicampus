package mc.sn.project.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;
//��ϵ� ���� ã�� ��
@Component("memberVO")
public class MemberVO {
	private String id;
	private String password;
	private String username;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public MemberVO() {
		
	}

	public MemberVO(String id, String pwd, String name) {
		this.id = id;
		this.setPassword(pwd);
		this.username = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}
